package com.wuweitao.entity.common;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Table;
import com.wuweitao.annotion.ValidateEntity;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;


/**
 * 回复实体类
 * @author wuweitao
 *
 */
@Entity
@Table(name="reply")
@EntityListeners(AuditingEntityListener.class)
public class Reply extends BaseEntity{

    private static final long serialVersionUID = 1L;

    @Column(name="comment_id",nullable=false)
    private int commentID;//回复针对的评论的id

    @ValidateEntity(required=true,requiredLeng=true,minLength=1,maxLength=1000,errorRequiredMsg="回复内容不能为空!",errorMinLengthMsg="回复长度需大于1!",errorMaxLengthMsg="回复长度不能大于1000!")
    @Column(name="content",nullable=false,length=1024)
    private String content;//回复内容

    @Column(name="from_uid",nullable=false)
    private int fromUid;//回复者的id

    @Column(name="to_uid",nullable=false)
    private int toUid;//回复者针对的评论者的id




}
