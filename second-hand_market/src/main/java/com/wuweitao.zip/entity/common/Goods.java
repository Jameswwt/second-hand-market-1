package com.wuweitao.entity.common;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Table;
import com.wuweitao.annotion.ValidateEntity;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;


/**
 * 商品实体类
 * @author wuweitao
 *
 */
@Entity
@Table(name="goods")
@EntityListeners(AuditingEntityListener.class)
public class Goods extends BaseEntity{

    public static final int GOODS_STATE_UP = 1;//上架
    public static final int GOODS_STATE_DOWN = 2;//下架
    public static final int GOODS_STATE_SOLD = 3;//已售出


    /**
     *
     */
    private static final long serialVersionUID = 1L;

    @ValidateEntity(required=true,errorRequiredMsg="请上传图片")
    @Column(name="photo",nullable=false,length=128)
    private String photo;//商品图片存放路径

    @ValidateEntity(required=true,requiredLeng=true,minLength=1,maxLength=30,errorRequiredMsg="商品名称不能为空!",errorMinLengthMsg="商品名称长度需大于1!",errorMaxLengthMsg="商品名称长度不能大于30!")
    @Column(name="name",nullable=false,length=32)
    private String name;//商品名称

    @ValidateEntity(required=true,requiredLeng=true,minLength=1,maxLength=1000,errorRequiredMsg="商品详情描述不能为空!",errorMinLengthMsg="商品详情描述长度需大于1!",errorMaxLengthMsg="商品详情描述长度不能大于1000!")
    @Column(name="description",nullable=false,length=1024)
    private String description;//商品详情描述

    @ValidateEntity(required=true,errorRequiredMsg="请填写购买价格",requiredMinValue=true,errorMinValueMsg="购买价格不能小于0")
    @Column(name="buy_price",nullable=false,length=8)
    private Float buyPrice;//购买价格

    @ValidateEntity(required=true,errorRequiredMsg="请填写出售价格",requiredMinValue=true,errorMinValueMsg="出售价格不能小于0")
    @Column(name="sell_price",nullable=false,length=8)
    private Float sellPrice;//出售价格

    @Column(name="stat",nullable=false,length=1)
    private int state = GOODS_STATE_UP;//商品状态，默认上架

    @Column(name="goods_category_id",nullable=true,length=1)
    private int goodsCategoryId;//e商品类别


    @Column(name="user_id",nullable=true)
    private int userID;//所属用户

    @Column(name="view_number",nullable=false,length=8)
    private int viewNumber = 0;//商品浏览量

    @Override
    public String toString() {
        return "Goods{" +
                "photo='" + photo + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", buyPrice=" + buyPrice +
                ", sellPrice=" + sellPrice +
                ", state=" + state +
                ", goodsCategoryId=" + goodsCategoryId +
                ", userID=" + userID +
                ", viewNumber=" + viewNumber +
                '}';
    }

    public static int getGoodsStateUp() {
        return GOODS_STATE_UP;
    }

    public static int getGoodsStateDown() {
        return GOODS_STATE_DOWN;
    }

    public static int getGoodsStateSold() {
        return GOODS_STATE_SOLD;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Float getBuyPrice() {
        return buyPrice;
    }

    public void setBuyPrice(Float buyPrice) {
        this.buyPrice = buyPrice;
    }

    public Float getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(Float sellPrice) {
        this.sellPrice = sellPrice;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public int getGoodsCategoryId() {
        return goodsCategoryId;
    }

    public void setGoodsCategoryId(int goodsCategoryId) {
        this.goodsCategoryId = goodsCategoryId;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public int getViewNumber() {
        return viewNumber;
    }

    public void setViewNumber(int viewNumber) {
        this.viewNumber = viewNumber;
    }
}
