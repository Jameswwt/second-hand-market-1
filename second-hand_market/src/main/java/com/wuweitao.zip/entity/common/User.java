package com.wuweitao.entity.common;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Table;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import com.wuweitao.annotion.ValidateEntity;


/**
 * 用户实体类
 * @author wuweitao
 *
 */
@Entity
@Table(name="user")
@EntityListeners(AuditingEntityListener.class)
public class User extends BaseEntity{

    public static final int USER_STATE_ENABLE = 1;//账号可用
    public static final int USER_STATE_UNABLE = 0;//账号被禁用

    /**User
     *
     */
    private static final long serialVersionUID = 1L;

    @ValidateEntity(required=true,requiredLeng=true,minLength=6,maxLength=18,errorRequiredMsg="学号/职工号不能为空!",errorMinLengthMsg="学号/职工号长度需大于6!",errorMaxLengthMsg="学号/职工号长度不能大于18!")
    @Column(name="school_number",nullable=false,length=18,unique=true)
    private String school_number;//学生学号/教师职工号

    @ValidateEntity(required=false)
    @Column(name="school",length=18)
    private String school;//所属学院

    @ValidateEntity(required=false)
    @Column(name="nickname",length=32)
    private String nickname;//昵称

    @ValidateEntity(required=false)
    @Column(name="mobile",length=18)
    private String mobile;//手机号

    @ValidateEntity(required=false)
    @Column(name="head_portrait",length=128)
    private String  headPortrait;//学生头像

    @ValidateEntity(required=false)
    @Column(name="state",length=1)
    private int state = USER_STATE_ENABLE;//用户账户状态，默认可用

    @ValidateEntity(required=true,requiredLeng=true,minLength=6,maxLength=18,errorRequiredMsg="密码不能为空!",errorMinLengthMsg="密码长度需大于6!",errorMaxLengthMsg="密码长度不能大于18!")
    @Column(name="password",nullable=false,length=18)
    private String password;//登录密码

    @Override
    public String toString() {
        return "User{" +
                "school_number='" + school_number + '\'' +
                ", school='" + school + '\'' +
                ", nickname='" + nickname + '\'' +
                ", mobile='" + mobile + '\'' +
                ", headPortrait='" + headPortrait + '\'' +
                ", state=" + state +
                ", password='" + password + '\'' +
                '}';
    }

    public static int getUserStateEnable() {
        return USER_STATE_ENABLE;
    }

    public static int getUserStateUnable() {
        return USER_STATE_UNABLE;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getSchool_number() {
        return school_number;
    }

    public void setSchool_number(String school_number) {
        this.school_number = school_number;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getHeadPortrait() {
        return headPortrait;
    }

    public void setHeadPortrait(String headPortrait) {
        this.headPortrait = headPortrait;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

