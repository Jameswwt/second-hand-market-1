package com.wuweitao.entity.common;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Table;
import com.wuweitao.annotion.ValidateEntity;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;


/**
 * 评论实体类
 * @author wuweitao
 *
 */
@Entity
@Table(name="comment")
@EntityListeners(AuditingEntityListener.class)
public class Comment extends BaseEntity{

    private static final long serialVersionUID = 1L;

    @Column(name="goods_id",nullable=false)
    private int goodsID;//在哪件商品下的评论

    @Column(name="from_uid",nullable=false)
    private int fromUid;//哪个用户的评论

    @ValidateEntity(required=true,requiredLeng=true,minLength=1,maxLength=1000,errorRequiredMsg="评论内容不能为空!",errorMinLengthMsg="评论长度需大于1!",errorMaxLengthMsg="评论长度不能大于1000!")
    @Column(name="content",nullable=false,length=1024)
    private String content;//评论内容

    @Override
    public String toString() {
        return "Comment{" +
                "goodsID=" + goodsID +
                ", fromUid=" + fromUid +
                ", content='" + content + '\'' +
                '}';
    }


    public int getGoodsID() {
        return goodsID;
    }

    public void setGoodsID(int goodsID) {
        this.goodsID = goodsID;
    }

    public int getFromUid() {
        return fromUid;
    }

    public void setFromUid(int fromUid) {
        this.fromUid = fromUid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }


}
