package com.wuweitao.dao.common;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wuweitao.entity.common.Comment;
/**
 * 评论物品数据库操作dao
 */
import com.wuweitao.entity.common.Goods;
import com.wuweitao.entity.common.User;

@Repository
public interface CommentDao extends JpaRepository<Comment, Long>,JpaSpecificationExecutor<Comment>{
    /**
     * 根据id获取
     * @return
     */
    @Query("select c from Comment c where c.id = :id")
    Comment find(@Param("id")Long id);

    /**
     * 根据用户查询
     * @param user
     * @return
     */
    List<Comment> findByUser(User user);

    /**
     * 根据商品查询
     * @param goods
     * @return
     */
    List<Comment> findByGoods(Goods goods);

    /**
     * 根据用户id和商品id查询
     * @param goodsId
     * @param userId
     * @return
     */
    @Query("select c from Comment c where c.goodsID = :goodsId and c.fromUid = :userId")
    Comment find(@Param("goodsId")Long goodsId,@Param("userId")Long userId);

}
