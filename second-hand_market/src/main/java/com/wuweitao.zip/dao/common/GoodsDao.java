package com.wuweitao.dao.common;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


/**
 * 商品数据库操作dao
 */
import com.wuweitao.entity.common.Goods;
import com.wuweitao.entity.common.User;
@Repository
public interface GoodsDao extends JpaRepository<Goods, Long>,JpaSpecificationExecutor<Goods> {
    /**
     * 根据id获取
     * @return
     */
    @Query("select g from Goods g where g.id = :id")
    Goods find(@Param("id")Long id);

    /**
     * 根据用户查询
     * @param user
     * @return
     */
    List<Goods> findByUser(User user);

    /**
     * 根据用户id和商品id查询
     * @param id
     * @param userId
     * @return
     */
    @Query("select g from Goods g where g.id = :id and g.userID = :userId")
    Goods find(@Param("id")Long id,@Param("userId")Long userId);

    /**
     * 获取指定状态的商品总数
     * @param state
     * @return
     */
    @Query("SELECT count(g) from Goods g where g.state = :state ")
    Long getTotalCount(@Param("state")Integer state);

    /**
     * 根据商品名称模糊搜索
     * @param name
     * @return
     */
    @Query(value="select * from second_hand_market_master_schemas_goods where name like %:name%",nativeQuery=true)
    List<Goods> findListByName(@Param("name")String name);
}
