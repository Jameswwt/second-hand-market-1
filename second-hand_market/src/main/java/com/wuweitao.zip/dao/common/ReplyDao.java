package com.wuweitao.dao.common;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wuweitao.entity.common.Comment;
/**
 * 回复数据库操作dao
 */

@Repository
public interface ReplyDao extends JpaRepository<Comment, Long>,JpaSpecificationExecutor<Comment>{

    /**
     * 根据id获取
     * @return
     */
    @Query("select r from Reply r where r.id = :id")
    Comment find(@Param("id")Long id);


    /**
     * 根据评论者id和回复者id查询
     * @param fromUid
     * @param toUid
     * @return
     */
    @Query("select r from Reply r where r.fromUid = :fromUid and r.toUid = :toUid")
    Comment find(@Param("fromUid")Long fromUid,@Param("toUid")Long toUid);






}
