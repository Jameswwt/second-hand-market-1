package com.wuweitao.dao.common;

/**
 * 用户信息操作dao类
 */
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wuweitao.entity.common.User;
@Repository
public interface UserDao extends JpaRepository<User, Long> {

    /**
     * 根据学号/职工号查询
     * @param school_number
     * @return
     */
    User findBySchoolNumber(String school_number);

    /**
     * 根据id查找
     * @param id
     * @return
     */
    @Query("select u from User u where u.id = :id")
    User find(@Param("id")Long id);
}
